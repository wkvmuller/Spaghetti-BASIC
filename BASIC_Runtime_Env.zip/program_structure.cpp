#include "program_structure.h"

// Define the global instance
PROGRAM_STRUCTURE program;
