#ifndef INTERPRETER_H
#define INTERPRETER_H

#include "program_structure.h"

void runInterpreter(PROGRAM_STRUCTURE& program);

#endif // INTERPRETER_H
